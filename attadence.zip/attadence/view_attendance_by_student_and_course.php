<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'attendance_system');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get student ID and course name from query
$studentId = $_GET['student_id'];
$courseName = $_GET['course_name'];

// Fetch attendance records for the selected student and course
$sql = "SELECT students.name AS student_name, students.course_name, attendance.attendance_date, attendance.status 
        FROM attendance 
        JOIN students ON attendance.student_id = students.id 
        WHERE attendance.student_id = '$studentId' AND students.course_name = '$courseName'";

$result = $conn->query($sql);
$attendanceRecords = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $attendanceRecords[] = [
            "student_name" => $row['student_name'],
            "course_name" => $row['course_name'],
            "date" => $row['attendance_date'],
            "status" => $row['status']
        ];
    }
}

echo json_encode(["attendance" => $attendanceRecords]);

$conn->close();
?>
