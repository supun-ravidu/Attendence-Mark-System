<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'attendance_system');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get course name from query
$courseName = $_GET['course_name'];

// Fetch students for the selected course
$sql = "SELECT id, name FROM students WHERE course_name = '$courseName'";
$result = $conn->query($sql);

$students = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $students[] = ["id" => $row['id'], "name" => $row['name']];
    }
}

echo json_encode(["students" => $students]);

$conn->close();
?>
