<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'attendance_system');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get student ID from request
$data = json_decode(file_get_contents("php://input"), true);
$studentId = $data['id'];

// Delete from database
$sql = "DELETE FROM students WHERE id = $studentId";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["message" => "Student deleted successfully"]);
} else {
    echo json_encode(["message" => "Error: " . $conn->error]);
}

$conn->close();
?>
