<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'attendance_system');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get dates from query string
$startDate = $_GET['start_date'];
$endDate = $_GET['end_date'];

// Fetch attendance records between the given dates
$sql = "SELECT students.name AS student_name, attendance.attendance_date, attendance.status 
        FROM attendance 
        JOIN students ON attendance.student_id = students.id 
        WHERE attendance.attendance_date BETWEEN '$startDate' AND '$endDate'";

$result = $conn->query($sql);
$attendanceRecords = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $attendanceRecords[] = [
            "studzent_name" => $row['student_name'],
            "date" => $row['attendance_date'],
            "status" => $row['status']
        ];
    }
}

echo json_encode(["attendance" => $attendanceRecords]);

$conn->close();
?>
