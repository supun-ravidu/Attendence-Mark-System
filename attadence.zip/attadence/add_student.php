<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'attendance_system');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get data from request
$data = json_decode(file_get_contents("php://input"), true);
$fullName = $data['fullName'];
$studentName = $data['studentName'];
$batchName = $data['batchName'];
$courseName = $data['courseName'];
$contactNumber = $data['contactNumber'];
$email = $data['email'];
$nic = $data['nic'];
$wubRegNo = $data['wubRegNo'];
$iiacRegNo = $data['iiacRegNo'];

// Insert into database
$sql = "INSERT INTO students (full_name, name, batch_name, course_name, contact_number, email, nic, wub_reg_no, iiac_reg_no) 
        VALUES ('$fullName', '$studentName', '$batchName', '$courseName', '$contactNumber', '$email', '$nic', '$wubRegNo', '$iiacRegNo')";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["message" => "Student added successfully"]);
} else {
    echo json_encode(["message" => "Error: " . $conn->error]);
}

$conn->close();
?>
