<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'attendance_system');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get course name and month from query
$courseName = $_GET['course_name'];
$selectedMonth = $_GET['month'];

// Extract year and month
$year = date('Y', strtotime($selectedMonth));
$month = date('m', strtotime($selectedMonth));

// Fetch attendance records for the selected course and month
$sql = "SELECT students.name AS student_name, students.course_name, attendance.attendance_date, attendance.status 
        FROM attendance 
        JOIN students ON attendance.student_id = students.id 
        WHERE students.course_name = '$courseName'
        AND YEAR(attendance.attendance_date) = '$year'
        AND MONTH(attendance.attendance_date) = '$month'";

$result = $conn->query($sql);

// Prepare headers for the Excel file download
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=monthly_attendance_{$courseName}_{$year}_{$month}.xls");
header("Pragma: no-cache");
header("Expires: 0");

// Generate the Excel table structure
echo "Student Name\tCourse\tDate\tAttendance Status\n";

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "{$row['student_name']}\t{$row['course_name']}\t{$row['attendance_date']}\t{$row['status']}\n";
    }
} else {
    echo "No records found\n";
}

$conn->close();
?>
