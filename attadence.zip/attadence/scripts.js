function addStudent() {
    const fullName = document.getElementById('full_name').value;
    const studentName = document.getElementById('student_name').value;
    const batchName = document.getElementById('batch_name').value;
    const courseName = document.getElementById('course_name').value;
    const contactNumber = document.getElementById('contact_number').value;
    const email = document.getElementById('email').value;
    const nic = document.getElementById('nic').value;
    const wubRegNo = document.getElementById('wub_reg_no').value;
    const iiacRegNo = document.getElementById('iiac_reg_no').value;

    fetch('add_student.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            fullName, studentName, batchName, courseName, contactNumber, email, nic, wubRegNo, iiacRegNo
        }),
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
    })
    .catch(error => console.error('Error:', error));
}


// Load students by course in the Mark Attendance section
function loadStudentsByCourse() {
    const courseName = document.getElementById('course_select').value;

    if (courseName) {
        fetch(`get_students_by_course.php?course_name=${courseName}`)
        .then(response => response.json())
        .then(data => {
            const studentSelect = document.getElementById('student_select');
            studentSelect.innerHTML = '';  // Clear previous options
            data.students.forEach(student => {
                const option = document.createElement('option');
                option.value = student.id;
                option.textContent = student.name;
                studentSelect.appendChild(option);
            });
        })
        .catch(error => console.error('Error:', error));
    }
}

// Mark attendance with Present or Absent status
function markAttendance() {
    const studentId = document.getElementById('student_select').value;
    const attendanceDate = document.getElementById('attendance_date').value;
    const attendanceStatus = document.getElementById('attendance_status').value;

    if (studentId && attendanceDate && attendanceStatus) {
        fetch('mark_attendance.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                studentId: studentId,
                attendanceDate: attendanceDate,
                attendanceStatus: attendanceStatus
            }),
        })
        .then(response => response.json())
        .then(data => {
            alert(data.message);
        })
        .catch(error => console.error('Error:', error));
    } else {
        alert("Please fill all fields.");
    }
}

// Load students by course in the View Attendance section
function loadStudentsByCourseForView() {
    const courseName = document.getElementById('course_select_view').value;

    if (courseName) {
        fetch(`get_students_by_course.php?course_name=${courseName}`)
        .then(response => response.json())
        .then(data => {
            const studentSelect = document.getElementById('student_select_view');
            studentSelect.innerHTML = '';  // Clear previous options
            data.students.forEach(student => {
                const option = document.createElement('option');
                option.value = student.id;
                option.textContent = student.name;
                studentSelect.appendChild(option);
            });
        })
        .catch(error => console.error('Error:', error));
    }
}





// Download attendance for a selected student and course as an Excel file
function downloadAttendance() {
    const studentId = document.getElementById('student_select_view').value;
    const courseName = document.getElementById('course_select_view').value;

    if (studentId && courseName) {
        const url = `download_attendance.php?student_id=${studentId}&course_name=${courseName}`;
        window.location.href = url;  // Trigger file download
    } else {
        alert("Please select both student and course.");
    }
}

















// View attendance for a selected student and course
function viewAttendanceByStudentAndCourse() {
    const studentId = document.getElementById('student_select_view').value;
    const courseName = document.getElementById('course_select_view').value;

    if (studentId && courseName) {
        fetch(`view_attendance_by_student_and_course.php?student_id=${studentId}&course_name=${courseName}`)
        .then(response => response.json())
        .then(data => {
            const tbody = document.getElementById('attendance-table').querySelector('tbody');
            tbody.innerHTML = '';  // Clear previous records
            data.attendance.forEach(record => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${record.student_name}</td>
                    <td>${record.course_name}</td>
                    <td>${record.date}</td>
                    <td>${record.status}</td>
                `;
                tbody.appendChild(row);
            });
        })
        .catch(error => console.error('Error:', error));
    } else {
        alert("Please select both student and course.");
    }
}
