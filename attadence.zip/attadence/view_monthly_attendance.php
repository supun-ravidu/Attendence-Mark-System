    <?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'attendance_system');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get course name and month from query
$courseName = $_GET['course_name'];
$selectedMonth = $_GET['month'];

// Extract year and month
$year = date('Y', strtotime($selectedMonth));
$month = date('m', strtotime($selectedMonth));

// Fetch attendance records for the selected course and month
$sql = "SELECT students.name AS student_name, students.course_name, attendance.attendance_date, attendance.status 
        FROM attendance 
        JOIN students ON attendance.student_id = students.id 
        WHERE students.course_name = '$courseName'
        AND YEAR(attendance.attendance_date) = '$year'
        AND MONTH(attendance.attendance_date) = '$month'";

$result = $conn->query($sql);
$attendanceRecords = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $attendanceRecords[] = [
            "student_name" => $row['student_name'],
            "course_name" => $row['course_name'],
            "date" => $row['attendance_date'],
            "status" => $row['status']
        ];
    }
}

echo json_encode(["attendance" => $attendanceRecords]);

$conn->close();
?>
