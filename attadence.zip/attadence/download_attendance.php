<?php
require 'vendor/autoload.php'; // Make sure this is the correct path to Composer's autoload file

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// Database connection
$conn = new mysqli('localhost', 'root', '', 'attendance_system');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get student ID and course name from the request
$studentId = $_GET['student_id'];
$courseName = $_GET['course_name'];

// Fetch attendance records for the selected student and course
$sql = "SELECT students.name AS student_name, students.course_name, attendance.attendance_date, attendance.status 
        FROM attendance 
        JOIN students ON attendance.student_id = students.id 
        WHERE attendance.student_id = '$studentId' AND students.course_name = '$courseName'";

$result = $conn->query($sql);

// Initialize PhpSpreadsheet object
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// Set headers for the Excel file
$sheet->setCellValue('A1', 'Student Name');
$sheet->setCellValue('B1', 'Course Name');
$sheet->setCellValue('C1', 'Date');
$sheet->setCellValue('D1', 'Attendance Status');

// Write data to the sheet
$row = 2; // Starting row for data
if ($result->num_rows > 0) {
    while ($attendance = $result->fetch_assoc()) {
        $sheet->setCellValue('A' . $row, $attendance['student_name']);
        $sheet->setCellValue('B' . $row, $attendance['course_name']);
        $sheet->setCellValue('C' . $row, $attendance['attendance_date']);
        $sheet->setCellValue('D' . $row, $attendance['status']);
        $row++;
    }
}

// Set headers to trigger download of the Excel file
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="attendance_records.xlsx"');
header('Cache-Control: max-age=0');

// Create and save the Excel file
$writer = new Xlsx($spreadsheet);
$writer->save('php://output');

// Close the database connection
$conn->close();
?>
