<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'attendance_system');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get data from the request
$data = json_decode(file_get_contents("php://input"), true);
$studentId = $data['studentId'];
$attendanceDate = $data['attendanceDate'];
$attendanceStatus = $data['attendanceStatus'];

// Validate input
if (empty($studentId) || empty($attendanceDate) || empty($attendanceStatus)) {
    echo json_encode(["message" => "Invalid input. Please fill all fields."]);
    exit;
}

// Insert or update attendance record into the database
$sql = "INSERT INTO attendance (student_id, attendance_date, status) 
        VALUES (?, ?, ?) 
        ON DUPLICATE KEY UPDATE status = ?";

// Prepare and bind parameters
$stmt = $conn->prepare($sql);
$stmt->bind_param("isss", $studentId, $attendanceDate, $attendanceStatus, $attendanceStatus);

if ($stmt->execute()) {
    echo json_encode(["message" => "Attendance marked successfully"]);
} else {
    echo json_encode(["message" => "Error: " . $stmt->error]);
}

// Close statement and connection
$stmt->close();
$conn->close();
?>
